package org.example;

public interface Likeable {
    void upvote();
    void downvote();
    int getVotes();
}
